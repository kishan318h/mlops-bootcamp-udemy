import os
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from pathlib import Path
import sys

## __file__ stores the path of the current directory
## going the grandparent directory
PACKAGE_ROOT = Path(os.path.abspath(os.path.dirname(__file__))).parent.parent
sys.path.append(str(PACKAGE_ROOT))


## since we have added the path of ROOT folder to sys.path,
## we can import the config file
from prediction_model.config import config


# Load the dataset
def load_dataset(file_name):
    filepath = os.path.join(config.DATAPATH, file_name)
    _data = pd.read_csv(filepath)
    _data.columns = [c.strip() for c in _data.columns] # removing extra spaces from column names
    return _data[config.FEATURES]


# separate X and y
def separate_data(data):
    X = data.drop(columns=[config.TARGET])
    y = data[config.TARGET]
    return X,y


# split data in train and test
def split_data(X, y, test_size=0.2, random_state=18):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=random_state)
    return X_train, X_test, y_train, y_test


# Serialization
def save_pipeline(pipeline_to_save):
    save_path = os.path.join(config.SAVE_MODEL_PATH, config.MODEL_NAME)
    joblib.dump(pipeline_to_save, save_path)
    print('Model has been saved under the name: ', config.MODEL_NAME)


# deserialization
def load_pipeline(pipeline_to_load):
    save_path = os.path.join(config.SAVE_MODEL_PATH, pipeline_to_load)
    model_loaded = joblib.load(save_path)
    print(f'Model has been loaded')
    return model_loaded